# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['inflammation']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.6.2,<4.0.0', 'numpy>=1.23.4,<2.0.0']

setup_kwargs = {
    'name': 'inflammation',
    'version': '1.0.0',
    'description': 'Analyse all day',
    'long_description': "# Introduction\n\nThis is a template software project repository used by the [Intermediate Research Software Development Skills In Python](https://github.com/carpentries-incubator/python-intermediate-development).\n\n## Purpose\n\nThis repository is intended to be used as a code template which is copied by learners at [Intermediate Research Software Development Skills In Python](https://github.com/carpentries-incubator/python-intermediate-development) workshops.\nThis can be done using the `Use this template` button towards the top right of this repo's GitHub page.\n\nThis software project is not finished, is currently failing to run and contains some code style issues. It is used as a starting point for the course - issues will be fixed and code will be added in a number of places during the course by learners in their own copies of the repository, as course topics are introduced.\n\n## Tests\n\nSeveral tests have been implemented already, some of which are currently failing.\nThese failing tests set out the requirements for the additional code to be implemented during the workshop.\n\nThe tests should be run using `pytest`, which will be introduced during the workshop.\n",
    'author': 'Sooraj Pradeep',
    'author_email': 'sooraj.pradeep@stfc.ac.uk',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
